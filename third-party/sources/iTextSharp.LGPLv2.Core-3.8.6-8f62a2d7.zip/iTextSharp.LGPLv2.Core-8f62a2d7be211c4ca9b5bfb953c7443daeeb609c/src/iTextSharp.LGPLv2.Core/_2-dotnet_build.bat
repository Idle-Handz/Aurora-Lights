dotnet build
pause